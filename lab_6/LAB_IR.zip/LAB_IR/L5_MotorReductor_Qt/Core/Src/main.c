/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "motorDriver.h"
#include "retardos.h"
#include <stdbool.h>
#include "usbd_cdc_if.h"
#include "ADC_IR_SENSOR.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define PI 3.14f

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim9;
TIM_HandleTypeDef htim10;
TIM_HandleTypeDef htim11;

/* USER CODE BEGIN PV */

/*
 *        ADC
 */
uint32_t canales[5] = {ADC_CHANNEL_0, ADC_CHANNEL_1, ADC_CHANNEL_2, ADC_CHANNEL_3, ADC_CHANNEL_4};
GPIO_TypeDef* puertos_led[4] = {GPIOB, GPIOB, GPIOA, GPIOA};
uint16_t pines_led[4] = {GPIO_PIN_15, GPIO_PIN_14, GPIO_PIN_8, GPIO_PIN_9};
uint16_t avgReadings[5];

IR_ConversionResult TRANS_CONVS;

uint32_t start_time = 0;
uint32_t stop_time = 0;
uint32_t TIEMPO = 0;
uint32_t contador=0;
uint32_t  tiempo=0;

uint16_t adcValue[5] = {0};
char texto [50];

int8_t numDatos=0;
uint8_t RPMEXTRA=0;
 //POSIBLE PROBLEMA FUTURO NO 8 BYTES
uint8_t rpm = 0;
uint16_t RPMX_DIV;
uint16_t Freq;
int16_t SPEEDE;
uint32_t PWM_PM;
uint32_t CHECK_PWM_PM;

//unsigned long datosRX[]
uint8_t muestra;

uint8_t datosRX[51];
volatile uint8_t indexRX = 0;
uint8_t datosTX[40];
uint8_t indexTX = 0;
//uint16_t overhead;
volatile int32_t posicionMotor =0;
uint8_t datosx [40];

volatile int i;
volatile bool bandera= 0;

volatile uint8_t TiempoRPM = 0;
volatile uint32_t GIROSX;
volatile uint32_t RPMX;
uint32_t  MMS;
volatile uint32_t TIMING;
volatile uint32_t TFULL;

volatile uint16_t RPM;
volatile uint16_t RPMTOTAL;

volatile int8_t revision;
volatile int32_t A=0;

volatile uint32_t GIROS;
volatile uint32_t TSEC_GIROS;

volatile uint32_t WDOG_TIME; //REVISO QUE LOS TIEMPOS SEAN PERFETOS E IMPOLUTOS ...
volatile uint32_t WD_PULSOS;

uint8_t COMUNICACION[10];
uint8_t pos = 0;//IKMPORTANTE NO BORRAR PARTE DEL ARREGLO COMUNICACION Y LA FUNCION FRAGMENTAR BYTE


//uint32_t numDatos;

typedef struct{
	uint8_t inicio_EN;
	uint8_t tamano_EN;
	uint8_t *datos_EN;  //RECORDOR NOMBRE
	uint8_t fin_EN;

}ENVIAPAQUETE;

ENVIAPAQUETE np;

typedef struct{
	uint8_t inicio;
	uint8_t tamano;
	uint8_t *datos;  //changeable
	uint8_t crc;
	uint8_t fin;

}PAQUETE;

PAQUETE pk1;



typedef enum{  ///// mi timer pro
    TLED=0,
	Tm2,
	TRPM,  //changeable
	Tm4,
	TTOTAL,

}TIMERS;

volatile uint32_t tim_pro[TTOTAL]; //MIS TIMERS CON ISR PRO


uint32_t timers[TTOTAL]  = {0};  // con esto se nombra a todos todos.

//uint32_t timers[TTOTAL]  = }0{;

uint8_t hola[] = {0xEE,0xF1};


void CDC_ReceiveCallBack(uint8_t* Buf, uint32_t len){

	memcpy(datosRX,Buf,len);
	indexRX = len;
}

uint8_t calcularCRC(uint8_t *datos, uint8_t tam) //el valor de tam cuando llega
{
	uint8_t crc = 0;

		for(int i=0; i<tam; i++)
		{
			crc ^= datos[i];
		}

	return crc;
}

int8_t serializarPaquete(const PAQUETE* paquete, uint8_t *buffer){   //serialize

	int idx =0;

	if(!paquete || !buffer)return -1;

	buffer[idx++] = paquete->inicio;
	buffer[idx++]= paquete->tamano;

		if(paquete->datos && (paquete->tamano>3)){   	//packet of data ;
		  memcpy(&buffer[idx], paquete->datos, (size_t)(paquete->tamano-4));
		  idx = idx + paquete->tamano-4;
		}

	uint8_t ss= (uint8_t)idx;
	buffer[idx++] =calcularCRC(buffer,ss);
	buffer[idx++] =paquete->fin;
	return idx;
}

void EnviarPaquete(uint8_t *dat, uint8_t tam){

	pk1.inicio = 0x77; //Start byte
	pk1.tamano = tam + 4;
	pk1.datos=datosx;

    memcpy(&pk1.datos[0], dat, tam + 4 );

	numDatos = serializarPaquete(&pk1, &datosTX);
	pk1.crc=calcularCRC(datosTX, tam+4);
	pk1.fin =0x12;

	CDC_Transmit_FS(datosTX, numDatos);  ///////////////////////////////////////////aQUI

} //way important to transmit


int ReciboPaquete(PAQUETE* paquete, uint8_t *pos){
   /* // Validar si hay datos
    if (datosRX[0] == 0x00) return -1;

    if (datosRX[0] == 0xC1) {

        if (datosRX[1] == LOMGSIZE) {
            uint8_t i = *pos;
            paquete->valor = (datosRX[i] << 8) | datosRX[i+1];  // ejemplo para campo de 2 bytes


            return 0;  // éxito
        }
    }

    if (datosTX[0] != 0xFF) {

    }

    return -2;  // Error si no se cumplió ninguna condición válida*/
}


int16_t ObtenerRPM(void)
{

    int32_t posicionM1 = __HAL_TIM_GET_COUNTER(&htim2);
    __HAL_TIM_SET_COUNTER(&htim5, 0);

    	while((__HAL_TIM_GET_COUNTER(&htim5) /10) <= 10); // 10 ms de espera  //PLOT CON 4
		int32_t posicionM2 = __HAL_TIM_GET_COUNTER(&htim2);
		int32_t diferenciaPulsos = posicionM2 - posicionM1;
		int16_t rpm = (int16_t)((diferenciaPulsos *60 *1000)  / (1135 *11));  //DIV 5

    return rpm;
}


int32_t W_frecuencia(void)
{
    float RPM_VEL = ObtenerRPM();
    float Frecuencia= ((RPM_VEL / 60.0) *(2 * PI));  //FREQ ANGULAR RAD/SEGUNDO OSEA OMEGA.
    return (int32_t)(Frecuencia);
}


int32_t VELINEAL(void) {  //VELOCIDAD LINEAL MILIMETROS POR SEGUNDO
    float Omega = W_frecuencia();
    float diametro_mm = 15.0;
    float Vlineal= ((Omega * (diametro_mm)) + 0.1);  //REVISAR PARENTESIS ANTES ERA 0.5
    return (int32_t)(Vlineal);
}


uint8_t fragmentacion(uint32_t dato, uint8_t frag_array[], uint8_t posicion) {

	/* MI FUNCION LLENA HACIA LA DERECHA DESDE LA POSICION QUE UNO DIGA LLENA 1 BYTE
	 *  POSICION DEPENDE DE MI Y ARREGLO Y DATO SON LOS QUE UNO QUIERE COMUNICAR PARA LA FUNCION ENVIARPAQUETE();
	 *  ADEMAS ORGANIZA AUTOMATICAMENTE.
	 */
	uint8_t i = 0;
    while (dato > 255) {
        frag_array[posicion + i] = 0xFF;
        dato -= 255;
        i++;
    }

    frag_array[posicion + i] = dato & 0xFF;
    int8_t NFRAG = i+1;
    return NFRAG; //  REVISAR NUMERO DE FRAGMENTACIONES EN VIVO...
}


////////////////////     AQUI NO DEPENDO DE  NADIE   //////////////

uint16_t VSPEED_QT(uint8_t* datosRX) {
    int16_t magnitud = (int16_t)((datosRX[4] << 8) | datosRX[5]);
    int8_t signo = (datosRX[3] == 0x01) ? -1 : 1;   // 0x01 = negativo  y 0x00 = positivo //AGREGO SIGNO
    return magnitud * signo;
}


int32_t Pwm_By_Speed(void) {

		/*       FUNCION QUE DESCRIBE ACELERACION
		 *               y = 0,1641x + 10
		 */
	    int16_t speed = VSPEED_QT(datosRX);
	    int8_t signo = (speed < 0) ? -1 : 1;
	    int16_t magnitud = (speed < 0) ? -speed : speed;

	    	float y = ((0.1641f * magnitud) + 7.7f);
	    	int32_t PerPWM = (int32_t)roundf(y);
	    	PerPWM *= signo;

	    	if (PerPWM > 100) {
	    	    PerPWM = 100;
	    	}
	    	else if (PerPWM < -100) {
	    	    PerPWM = -100;
	    	}
	    	else if (PerPWM >= 0 && PerPWM <= 4) {
	    	    PerPWM = 0;
	    	}

	    return PerPWM;
	}

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM9_Init(void);
static void MX_TIM4_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM11_Init(void);
static void MX_TIM5_Init(void);
static void MX_TIM10_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  CONVERTER_INIT(&hadc1, &htim10, canales, puertos_led, pines_led);

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM2_Init();
  MX_USB_DEVICE_Init();
  MX_TIM3_Init();
  MX_TIM9_Init();
  MX_TIM4_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM11_Init();
  MX_TIM5_Init();
  MX_TIM10_Init();
  /* USER CODE BEGIN 2 */

  motoresInit(&htim4, TIM_CHANNEL_1, TIM_CHANNEL_2); //MOTORES

  HAL_TIM_Base_Start_IT(&htim11);  //ESTOY TRABAJANDO ISR PARA TIM.  :)
  HAL_TIM_Base_Start(&htim9); //ESTO PUDE CAUSAR DESFASE CREO
  HAL_TIM_Base_Start(&htim5);

  delay_us_tim_init();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */


HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);  //importante por encoder mode t1, t2.
HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
HAL_ADC_Start_DMA(&hadc1, adcValue,5);

  while (1)
  {
	  WD_PULSOS = 0;

	  posicionMotor = __HAL_TIM_GET_COUNTER(&htim2); //DEJAR QUIETO
	  GIROSX = posicionMotor; //IMPORTANT

	  switch(datosRX[2])
	  {

	  case 0xA1: PWM_PM = Pwm_By_Speed(); motores(PWM_PM,0);
		  break;

	  case 0x00: motores(0,0); // CHECK_PWM_PM = 0;
		  break;

	  case 0xA2: motores(-80,0);
		  break;

	  }

	  	  SPEEDE = VSPEED_QT(datosRX);

      if(tim_pro[TLED]==0){
    	  tim_pro[TLED]=200; //LLENO CASILLA DE ESE ARREGLO
    	  HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);


      }

	  Delay_ms(1);
	  tiempo++;

	  RPM = ObtenerRPM();
	  TIMING =  (__HAL_TIM_GET_COUNTER(&htim5) /10); //REVISAR
	  Freq = W_frecuencia();
	  MMS =  VELINEAL();
	  TFULL +=  TIMING;



	  ReadAndAverageSensors(avgReadings, 10);
	  TRANS_CONVS = CONV_Y_TRANS();

	  revision = fragmentacion(RPM, COMUNICACION, 0);
	  fragmentacion(MMS, COMUNICACION, 2);
	  fragmentacion(Freq, COMUNICACION, 5);
	  fragmentacion(TRANS_CONVS.DIST1, COMUNICACION, 8);
	  fragmentacion(TRANS_CONVS.DIST2, COMUNICACION, 9);
	  fragmentacion(TRANS_CONVS.DIST3, COMUNICACION, 10);
	  fragmentacion(TRANS_CONVS.DIST4, COMUNICACION, 11);
	 // EnviarPaquete(COMUNICACION, 8);



	  /////LAB ANTERIOR


	  WDOG_TIME = __HAL_TIM_GET_COUNTER(&htim11)/10; //OBTENGO TIEMPO ESPECIFICO EN MILISEGUNDOS.

	  /*
	  sprintf(texto, "%5lu %5lu\n", MMS,TFULL);
	  CDC_Transmit_FS(texto, strlen(texto));
	  		  WDOG_TIME=__HAL_TIM_SET_COUNTER(&htim11,0);
	  */

	  //SUP=__HAL_TIM_GET_COUNTER(&htim11)/10;

  /////////////IMPORTANTE NO BORRRARRRR/////////////////
	  if(WDOG_TIME>200){
		  EnviarPaquete(COMUNICACION, 12);

  		  WDOG_TIME=__HAL_TIM_SET_COUNTER(&htim11,0);
	  }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 5;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 9600-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 15;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 15;
  if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 26-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 100-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 9600-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 4294967295;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * @brief TIM9 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM9_Init(void)
{

  /* USER CODE BEGIN TIM9_Init 0 */

  /* USER CODE END TIM9_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};

  /* USER CODE BEGIN TIM9_Init 1 */

  /* USER CODE END TIM9_Init 1 */
  htim9.Instance = TIM9;
  htim9.Init.Prescaler = 96-1;
  htim9.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim9.Init.Period = 65535;
  htim9.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim9.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim9, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM9_Init 2 */

  /* USER CODE END TIM9_Init 2 */

}

/**
  * @brief TIM10 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM10_Init(void)
{

  /* USER CODE BEGIN TIM10_Init 0 */

  /* USER CODE END TIM10_Init 0 */

  /* USER CODE BEGIN TIM10_Init 1 */

  /* USER CODE END TIM10_Init 1 */
  htim10.Instance = TIM10;
  htim10.Init.Prescaler = 96-1;
  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim10.Init.Period = 65535;
  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM10_Init 2 */

  /* USER CODE END TIM10_Init 2 */

}

/**
  * @brief TIM11 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM11_Init(void)
{

  /* USER CODE BEGIN TIM11_Init 0 */

  /* USER CODE END TIM11_Init 0 */

  /* USER CODE BEGIN TIM11_Init 1 */

  /* USER CODE END TIM11_Init 1 */
  htim11.Instance = TIM11;
  htim11.Init.Prescaler = 96-1;
  htim11.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim11.Init.Period = 1000-1;
  htim11.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim11.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim11) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM11_Init 2 */

  /* USER CODE END TIM11_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9
                          |GPIO_PIN_10, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA6 PA7 PA8 PA9
                           PA10 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9
                          |GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB12 PB14 PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */


void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	//HAL_ADC_Start_DMA(&hadc1, adcValue,5);///////////////////////////////// PILAS SI NO FUNCIONA
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  //  static uint16_t ms_counter = 0; declarado arriba

    if (htim->Instance == TIM11) {

        for (uint16_t i = 0; i < TTOTAL; i++) {
            if (tim_pro[i] != 0) {
                tim_pro[i]--;
            }
        }

    }

}




/*
void CDC_ReceiveCallBack(uint8_t* Buf, uint32_t Len){
	mempcy(datosRX,Buf,Len);
	indexRX = Len;
}*/

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
