/*
 * mms_rpm.c
 *
 *  Created on: Apr 22, 2025
 *      Author: crist
 */


#include "mms_rpm.h"
#include <math.h>

//extern TIM_HandleTypeDef htim2;
//extern TIM_HandleTypeDef htim5;   //NO USAR EXTERN

/*
int16_t ObtenerRPM(void)
{
    int32_t posicionM1 = __HAL_TIM_GET_COUNTER(&htim2);
    __HAL_TIM_SET_COUNTER(&htim5, 0);

    while ((__HAL_TIM_GET_COUNTER(&htim5) / 10) <= 10); // Espera 10 ms

    int32_t posicionM2 = __HAL_TIM_GET_COUNTER(&htim2);
    int32_t diferenciaPulsos = posicionM2 - posicionM1;

    int16_t rpm = (int16_t)((diferenciaPulsos * 60 * 1000) / (1135 * 11));
    return rpm;
}

int32_t W_frecuencia(void)
{
    float RPM_VEL = ObtenerRPM();
    float Frecuencia = (RPM_VEL / 60.0f) * (2.0f * PI);
    return (int32_t)(Frecuencia);
}

int32_t VELINEAL(void)
{
    float Omega = W_frecuencia();
    float diametro_mm = 15.0f;
    float Vlineal = (Omega * diametro_mm) + 0.1f;
    return (int32_t)(Vlineal);
}
*/

