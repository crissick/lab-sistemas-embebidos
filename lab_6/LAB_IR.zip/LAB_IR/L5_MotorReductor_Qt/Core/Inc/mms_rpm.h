/*
 * mms_rpm.h
 *
 *  Created on: Apr 22, 2025
 *      Author: crist
 */

#ifndef INC_MMS_RPM_H_
#define INC_MMS_RPM_H_


#include <stdint.h>
//#include "stm32f1xx_hal.h"

#define PI 3.14159265358979323846f

int16_t ObtenerRPM(void);
int32_t W_frecuencia(void);
int32_t VELINEAL(void);

#endif /* INC_MMS_RPM_H_ */
