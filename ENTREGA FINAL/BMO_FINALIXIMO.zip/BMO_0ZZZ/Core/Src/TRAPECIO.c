/*
 * TRAPECIO.c
 *
 *  Created on: May 10, 2025
 *      Author: YEISON LARA
 */

#include "TRAPECIO.h"

float TIEMPO_ACUM = 0;
float DIST_ACUM = 0;
float VEL_FINAL = 0;
float mm_FINAL = 0;
float DIS_ACCE = 0;
float DIS_DESACCE = 0;
float AceleracionGlobal = 0;
static float v_desired = 0.0f;
float VEL_INICIAL_GLOBAL = 0.0f;

 bool backflag =0;

 ////////////////////////////////////////////////////////////////////////////////////////////////
 // trapecio_perpetuo:
 //   avance_odo_real   = distancia recorrida (mm) desde el último “start”
 //   dt                 = tiempo transcurrido (s) desde la última llamada
 //   d_sensor           = distancia actual detectada por el sensor IR (mm)
 //   ACELERATION        = aceleración constante (mm/s²)
 //   VEL_IN             = velocidad pico nominal (mm/s)
 //   VEL_MIN_SENSOR     = velocidad mínima cuando d_sensor ≤ DIST_MIN_SENSOR
 //   DIST_MIN_SENSOR    = umbral inferior de distancia para VEL_MIN_SENSOR (mm)
 //   DIST_MAX_SENSOR    = umbral superior de distancia para VEL_IN (mm)
 //
 // Devuelve la velocidad deseada en mm/s, recalculada cada llamada.

 float trapecio_perpetuo(float avance_odo_real,  float dt,  float d_sensor, float ACELERATION, float VEL_IN, float VEL_MIN_SENSOR, float DIST_MIN_SENSOR, float DIST_MAX_SENSOR)
 {
	    static float v_desired = 0.0f;
	    float a = ACELERATION;

	    if (d_sensor <= 0.0f) {
	        v_desired = 0.0f;
	        return 0.0f;
	    }

	    float VEL_FINAL;
	    if (d_sensor >= DIST_MAX_SENSOR) {
	        VEL_FINAL = VEL_IN;
	    }
	    else if (d_sensor <= DIST_MIN_SENSOR) {
	        VEL_FINAL = VEL_MIN_SENSOR;
	    }
	    else {
	        float alpha = (d_sensor - DIST_MIN_SENSOR)
	                    / (DIST_MAX_SENSOR - DIST_MIN_SENSOR);
	        VEL_FINAL = VEL_MIN_SENSOR + alpha * (VEL_IN - VEL_MIN_SENSOR);
	    }

	    float s_brake = (v_desired * v_desired) / (2.0f * a);


	    if (s_brake >= d_sensor) {
	        v_desired -= a * dt;
	        if (v_desired < 0.0f) v_desired = 0.0f;
	    }
	    else if (v_desired < VEL_FINAL) {
	        v_desired += a * dt;
	        if (v_desired > VEL_FINAL) v_desired = VEL_FINAL;
	    }
	    else {
	        v_desired = VEL_FINAL;
	    }

	    return v_desired;
 }




 /*


 float trapecio_perpetuo_con_umbral(
     float avance_odo_real,
     float dt,
     float d_sensor,
     float ACELERATION,
     float VEL_IN,
     float VEL_MIN_SENSOR,
     float DIST_MIN_SENSOR,
     float DIST_MAX_SENSOR,
     float speed_threshold,
     float dist_umbral,
     int *pStartDecel
 ) {
     static float v_desired = 0.0f;
     static float prev_v_desired = 0.0f;
     static int decel_already_triggered = 0;
     static int mmdesired_enabled = 0;
     float a = ACELERATION;
     if (pStartDecel) {
         *pStartDecel = 0;
     }
     if (d_sensor < dist_umbral) {
         if (!mmdesired_enabled) {
             mmdesired_enabled = 1;
             decel_already_triggered = 0;
         }
     } else {
         if (mmdesired_enabled) {
             mmdesired_enabled = 0;
             decel_already_triggered = 0;
             v_desired = 0.0f;
         }
     }
     if (d_sensor <= 0.0f) {
         prev_v_desired = v_desired;
         v_desired = 0.0f;
         decel_already_triggered = 0;
         return 0.0f;
     }
     float VEL_FINAL;
     if (d_sensor >= DIST_MAX_SENSOR) {
         VEL_FINAL = VEL_IN;
     } else if (d_sensor <= DIST_MIN_SENSOR) {
         VEL_FINAL = VEL_MIN_SENSOR;
     } else {
         float alpha = (d_sensor - DIST_MIN_SENSOR) / (DIST_MAX_SENSOR - DIST_MIN_SENSOR);
         VEL_FINAL = VEL_MIN_SENSOR + alpha * (VEL_IN - VEL_MIN_SENSOR);
     }
     float s_brake = (v_desired * v_desired) / (2.0f * a);
     prev_v_desired = v_desired;
     if (mmdesired_enabled) {
         if (s_brake >= d_sensor) {
             v_desired -= a * dt;
             if (v_desired < 0.0f) v_desired = 0.0f;
         } else if (v_desired < VEL_FINAL) {
             v_desired += a * dt;
             if (v_desired > VEL_FINAL) v_desired = VEL_FINAL;
         } else {
             v_desired = VEL_FINAL;
         }
     } else {
         v_desired = 0.0f;
     }
     if (mmdesired_enabled && !decel_already_triggered) {
         if (prev_v_desired > speed_threshold && v_desired <= speed_threshold) {
             decel_already_triggered = 1;
             if (pStartDecel) {
                 *pStartDecel = 1;
             }
         }
     }
     return v_desired;
 }






*/








 /////////////////////////////////////////////////////////////////////////////////////////////////

 float trapecio(float avance_odo_real, float mm_desired, float dt, float ACELERATION, float VEL_IN, float VEL_INICIAL)
 {
    static int   first_call = 1;

     	 if (first_call) {
     		 v_desired  = VEL_INICIAL;
         first_call = 0;
         if (v_desired > VEL_IN) {
             v_desired = VEL_IN;
         }
     	 }

     float VEL_FINAL = VEL_IN;            // meseta deseada
     float a         = ACELERATION;
     float s_total   = mm_desired;        // distancia objetivo
     float s_now     = avance_odo_real;   // distancia recorrida
	 float s_acce       = (VEL_FINAL * VEL_FINAL) / (2.0f * a);
	 float s_start_freno = s_total - s_acce;

     	 if (s_total < 2.0f * s_acce) {
         float s_mitad = s_total * 0.5f;
         if (s_now < s_mitad) {
        	 v_desired += a * dt;
		 if (v_desired > VEL_FINAL) v_desired = VEL_FINAL;
         } else {
        	 v_desired -= a * dt;
		 if (v_desired < 0.0f) v_desired = 0.0f;
         }
     	 }
     	 else {
         if (s_now < s_acce) {
        	 v_desired += a * dt;
		 if (v_desired > VEL_FINAL) v_desired = VEL_FINAL;
         }
         else if (s_now < s_start_freno) {
        	 v_desired = VEL_FINAL;
         }
         else {
        	 v_desired -= a * dt;
		 if (v_desired < 0.0f) v_desired = 0.0f;
         }
     }

     return v_desired;
 }

/*
 float trapecio(
     float avance_odo_real,
     float mm_desired,
     float dt,
     float ACELERATION,
     float VEL_IN,
     float VEL_INICIAL
 ) {
     static int   first_call = 1;
     static float v_desired  = 0.0f;

     if (first_call) {
         v_desired  = VEL_INICIAL;
         if (v_desired > VEL_IN) {
             v_desired = VEL_IN;
         }
         first_call = 0;
     }

     float a           = (ACELERATION >= 0.0f) ? ACELERATION : -ACELERATION;
     float brake_dist  = (v_desired * v_desired) / (2.0f * a);
     float dist_remain = mm_desired - avance_odo_real;

     if (dist_remain > brake_dist) {
         // Acelera
         v_desired += a * dt;
         if (v_desired > VEL_IN) {
             v_desired = VEL_IN;
         }
     } else {
         // Desacelera
         v_desired -= a * dt;
         if (v_desired < 0.0f) {
             v_desired = 0.0f;
         }
     }

     return v_desired;
 }*/

 float trapecio_Angular(float avance_ang_real, float ang_desired, float dt, float accel, float vel_max, float v_start) {

     if (ang_desired >  5.7f) ang_desired =  5.7f;
     if (ang_desired < -5.7f) ang_desired = -5.7f;

     int signo = (ang_desired >= 0.0f) ? 1 : -1;
     float D    = fabsf(ang_desired);
     float x    = fabsf(avance_ang_real);

     static float last_D = 0.0f;
     if (D != last_D) {
         v_desired = 0.0f;
         last_D    = D;
     }

     if (x >= D) {
         v_desired = 0.0f;
         return 0.0f;
     }

     float v_theo_acel  = sqrtf(2.0f * accel * x);
     float v_theo_decel = sqrtf(2.0f * accel * (D - x));
     float v_theo       = fminf(v_theo_acel, v_theo_decel);
     v_theo = fminf(v_theo, vel_max);

     v_desired += accel * dt;
     v_desired  = fminf(v_desired, v_theo);
     v_desired  = fmaxf(v_desired, v_start);

     return (signo * v_desired) * 3.0f;
 }
