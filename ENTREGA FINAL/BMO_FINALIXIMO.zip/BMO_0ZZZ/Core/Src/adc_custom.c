/*
 * adc_custom.c
 *
 *  Created on: Aug 12, 2024
 *      Author: CamiloA
 */
#include "main.h"
#include "adc_custom.h"


float DIST1;
float DIST2;
float DIST3;
float DIST4;
float BATT;


const int8_t mIR1 = -43.62; //-43.62 original
const int8_t mIR2 = -67.11; //-51.51 original
const int8_t mIR3 = -57.84;
const int8_t mIR4 = -60.11;

void ADC_Init_Custom(ADC_HandleTypeDef *use_hadc){

	   use_hadc->Instance = ADC1;
	   use_hadc->Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	   use_hadc->Init.Resolution = ADC_RESOLUTION_12B;
	   use_hadc->Init.ScanConvMode = DISABLE;
	   use_hadc->Init.ContinuousConvMode = DISABLE;
	   use_hadc->Init.DiscontinuousConvMode = DISABLE;
	   use_hadc->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	   use_hadc->Init.ExternalTrigConv = ADC_SOFTWARE_START;
	   use_hadc->Init.DataAlign = ADC_DATAALIGN_RIGHT;
	   use_hadc->Init.NbrOfConversion = 1;
	   use_hadc->Init.DMAContinuousRequests = DISABLE;
	   use_hadc->Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	   if (HAL_ADC_Init(use_hadc) != HAL_OK)
	   {
	     Error_Handler();
	   }

}


//Parametro para seleccionar el canal:
//ADC_CHANNEL_0
uint32_t ADC_SelectCH(ADC_HandleTypeDef *use_hadc, uint32_t Channel){

	ADC_ChannelConfTypeDef sConfig = {0};
	uint32_t result;

	sConfig.Channel = Channel;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	if (HAL_ADC_ConfigChannel(use_hadc, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	HAL_ADC_Start(use_hadc);
	HAL_ADC_PollForConversion(use_hadc, 1000);
	result= HAL_ADC_GetValue(use_hadc);
	HAL_ADC_Stop(use_hadc);
	return result;
}

uint32_t CONV_Y_TRANS(long ADCLECTURE,uint8_t POS_IR)
{
	switch(POS_IR)
	{
		case 1:	   DIST1 = mIR1 * log(ADCLECTURE) + 373.25;
		if(DIST1 > 255)DIST1 = 200;
		if(DIST1 < 0)DIST1 = 0;
		return DIST1;
			break;
		case 2:    DIST2 = mIR2 * log(ADCLECTURE) + 540.52; //439.42 original
		//if(DIST2>255)DIST2 = 255;
		//if(DIST2 < 0)DIST2 = 0;
		return DIST2;
			break;
		case 3:    DIST3 = mIR3 * log(ADCLECTURE) + 494.28;
		if(DIST3>255)DIST3 = 200;
		if(DIST3 < 0)DIST3 = 0;
		return DIST3;
			break;
		case 4:    DIST4 = mIR4 * log(ADCLECTURE) + 488.57; //488.57 original
		if(DIST4>255)DIST4 = 200;
		if(DIST4 < 0)DIST4 = 0;
		return DIST4;
			break;
	}
}
