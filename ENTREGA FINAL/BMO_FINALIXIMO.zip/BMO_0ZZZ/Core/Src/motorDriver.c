/*
 * motorDriver.c
 *
 *  Created on: Mar 6, 2025
 *      Author: CamiloA
 */

#include "motorDriver.h"

TIM_HandleTypeDef *timmotorGlobal;




#include "motorDriver.h"
#include <math.h>  // para roundf()

volatile float prev_pwm_r = 0.0f;

volatile float prev_pwm_l = 0.0f;
// Prototipos de funciones (no usan extern)

float aplicarEMA( float dato, float dato_anterior, float alpha)
{

	float ema = (alpha * dato) + ((1 - alpha) * dato_anterior);
	return ema;
}

 int32_t filterPWM_R(int32_t raw_pwm) {
    float f = aplicarEMA((float)raw_pwm, prev_pwm_r, 0.3);
    prev_pwm_r = f;
    return (int32_t)roundf(f);
}

 int32_t filterPWM_L(int32_t raw_pwm) {
    float f = aplicarEMA((float)raw_pwm, prev_pwm_l, 0.3);
    prev_pwm_l = f;
    return (int32_t)roundf(f);
}

// ------------------------------------------------------
int32_t Pwm_By_Speed_normalR(float vars) {
    int16_t speed = (int16_t)vars;
    int8_t signo  = (speed < 0) ? -1 : 1;
    int16_t mag   = (speed < 0) ? -speed : speed;

    // 1) Mapeo magnitud→PWM bruto
    float y      = (0.1641f * mag) + 2.0f;
    int32_t pwm  = (int32_t)roundf(y) * signo;

    // 2) Saturaciones
    if (pwm >  100) pwm =  100;
    if (pwm < -100) pwm = -100;
    if (pwm >= 0 && pwm <= 4) pwm = 0;

    // 3) Filtrado EMA
    return filterPWM_R(pwm);
}

int32_t Pwm_By_Speed_normalL(float vars) {
    int16_t speed = (int16_t)vars;
    int8_t signo  = (speed < 0) ? -1 : 1;
    int16_t mag   = (speed < 0) ? -speed : speed;

    float y      = (0.1641f * mag) + 4.0f;
    int32_t pwm  = (int32_t)roundf(y) * signo;

    if (pwm >  100) pwm =  100;
    if (pwm < -100) pwm = -100;
    if (pwm >= 0 && pwm <= 4) pwm = 0;

    return filterPWM_L(pwm);
}

/*
int32_t Pwm_By_Speed_normalR(float vars) {


	    int16_t speed = (int16_t) vars;
	    int8_t signo = (speed < 0) ? -1 : 1;
	    int16_t magnitud = (speed < 0) ? -speed : speed;

	    	float y = ((0.1641f * magnitud) + 2.0f);
	    	int32_t PerPWM = (int32_t)roundf(y);
	    	PerPWM *= signo;

	    	if (PerPWM > 100) {
	    	    PerPWM = 100;
	    	}
	    	else if (PerPWM < -100) {
	    	    PerPWM = -100;
	    	}
	    	else if (PerPWM >= 0 && PerPWM <= 4) {
	    	    PerPWM = 0;
	    	}

	    return PerPWM;
	}


int32_t Pwm_By_Speed_normalL(float vars) {

	    int16_t speed = (int16_t) vars;
	    int8_t signo = (speed < 0) ? -1 : 1;
	    int16_t magnitud = (speed < 0) ? -speed : speed;

	    	float y = ((0.1641f * magnitud) + 4.0f);
	    	int32_t PerPWM = (int32_t)roundf(y);
	    	PerPWM *= signo;

	    	if (PerPWM > 100) {
	    	    PerPWM = 100;
	    	}
	    	else if (PerPWM < -100) {
	    	    PerPWM = -100;
	    	}
	    	else if (PerPWM >= 0 && PerPWM <= 4) {
	    	    PerPWM = 0;
	    	}

	    return PerPWM;
	}


*/


void motoresInit(TIM_HandleTypeDef *timmotor, uint32_t canal1, uint32_t canal2){
	timmotorGlobal = timmotor;
	HAL_TIM_PWM_Start(timmotorGlobal, canal1);   // OUT PWMA
	HAL_TIM_PWM_Start(timmotorGlobal, canal2);  // OUT PWMB
	timmotorGlobal->Instance->CCR1 = 0;
	timmotorGlobal->Instance->CCR2 = 0;

	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,0);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,0);
}

void motores(int32_t m1, int32_t m2){

	//control motor 1
	int8_t pwmM1 = Pwm_By_Speed_normalL(m1); //L

    int8_t pwmM2 = Pwm_By_Speed_normalR(m2); //R

	if(pwmM1 > 0){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0);
		if(pwmM1 > 100)pwmM1 = 100;
		timmotorGlobal->Instance->CCR1 = pwmM1;
	}else if(pwmM1 < 0){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,1);
		pwmM1 *= -1;
		if(pwmM1 > 100)pwmM1 = 100;     //L
		timmotorGlobal->Instance->CCR1 = pwmM1;
	}else{                                       /// NORMALMENTE SOLO EJECUTA EN 0,0 FREE
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0);
		timmotorGlobal->Instance->CCR1 = 0;  //LEFT
	}

	//control motor 2
	if(pwmM2 > 0){
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,1);  //COMANDO ADELANTE
		HAL_GPIO_WritePin(GPIOB	, GPIO_PIN_10,0);
		if(pwmM2 > 100)pwmM2 = 100;
		timmotorGlobal->Instance->CCR2 = pwmM2;
	}else if(pwmM2 < 0){
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,0);   //COMANDO ATRAS
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10,1);
		pwmM2 *= -1;
		if(pwmM2 > 100)pwmM2 = 100;
		timmotorGlobal->Instance->CCR2 = pwmM2;  //R
	}else{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10,0);
		timmotorGlobal->Instance->CCR2 = 0;  //RIGHT
	}

}
