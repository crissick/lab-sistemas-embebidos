/*
 * motorDriver.h
 *
 *  Created on: Mar 6, 2025
 *      Author: CamiloA
 */

#ifndef INC_MOTORDRIVER_H_
#define INC_MOTORDRIVER_H_

#include "main.h"

float aplicarEMA(float dato, float dato_anterior, float alpha);
void motoresInit(TIM_HandleTypeDef *timmotor, uint32_t canal1, uint32_t canal2);
void motores(int32_t m1, int32_t m2);
int32_t Pwm_By_Speed_normalR(float vars);
int32_t Pwm_By_Speed_normalL(float vars);


#endif /* INC_MOTORDRIVER_H_ */
