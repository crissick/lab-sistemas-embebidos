/*
 * TRAPECIO.h
 *
 *  Created on: May 10, 2025
 *      Author: putom
 */

#ifndef TRAPECIO_H_
#define TRAPECIO_H_
#include "main.h"
#include <stdbool.h>
#include "math.h"


float trapecio(float avance_odo_real, float mm_desired, float dt, float ACELERATION, float VEL_IN, float VEL_INICIAL);

float trapecio_Angular(float avance_ang_real,float ang_desired,float dt,float accel,float vel_max,float v_start);

#endif /* TRAPECIO_H_ */
