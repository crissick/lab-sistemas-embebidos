/*
 * MOVEMENT_MM.h
 *
 *  Created on: May 10, 2025
 *      Author: putom
 */

#ifndef MOVEMENT_MM_H_
#define MOVEMENT_MM_H_

#include "main.h"
#include "math.h"

uint16_t VSPEED_QT(uint8_t* DatosRX);
int32_t Pwm_By_Speed_normal(float vars);


#endif /* MOVEMENT_MM_H_ */
