/*
 * PID_MM.h
 *
 *  Created on: May 11, 2025
 *      Author: YEISON LARA
 */

// PID_MM.h

#ifndef PID_MM2_H_
#define PID_MM2_H_

#include "main.h"
#include <stdbool.h>

typedef struct {
    float Kp;
    float Kd;
    float ERR_ANT;
} VARIABLES_PID;

void PID_Init_Linear( float kp, float kd );
void PID_Init_Angular(float kp, float kd );

float PID_Update_Linear( float error, float dt );
float PID_Update_Angular(float error, float dt );

#endif /* PID_MM_H_ */
