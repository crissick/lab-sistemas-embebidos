/*
 * MOVEMENT_MM.c
 *
 *  Created on: May 10, 2025
 *      Author: YEISON LARA
 */

#include "MOVEMENT_MM.h"

uint16_t VSPEED_QT(uint8_t* DatosRX) {   //desde qt arreglo posible bloqueo... mms negativo
    int16_t magnitud = (int16_t)((DatosRX[4] << 8) | DatosRX[5]);
    int8_t signo = (DatosRX[3] == 0x01) ? -1 : 1;   // 0x01 = negativo  y 0x00 = positivo //AGREGO SIGNO
    return magnitud * signo;
}  ////REVISAR VALOR QUE SALE DE QT CUANDO ES UN VALOR NEGATIVO.






int32_t Pwm_By_Speed_normal(float vars) {

		/*       FUNCION QUE DESCRIBE ACELERACION
		 *               y = 0,1641x + 10
		 */


	    float speed = vars;
	    float signo = (speed < 0.0f) ? -1.0f : 1.0f;
	    float magnitud = (speed < 0.0f) ? -speed : speed;

	    	float y = ((0.1641f * magnitud) + 2.0f);
	    	int32_t PerPWM = (int32_t)roundf(y);
	    	PerPWM *= signo;

	    	if (PerPWM > 100) {
	    	    PerPWM = 100;
	    	}
	    	else if (PerPWM < -100) {
	    	    PerPWM = -100;
	    	}
	    	else if (PerPWM >= 0 && PerPWM <= 2) {
	    	    PerPWM = 0;
	    	}
	    return PerPWM;
	}
