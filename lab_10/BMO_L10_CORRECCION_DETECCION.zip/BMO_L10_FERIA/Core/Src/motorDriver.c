/*
 * motorDriver.c
 *
 *  Created on: Mar 6, 2025
 *      Author: CamiloA
 */

#include "motorDriver.h"

TIM_HandleTypeDef *timmotorGlobal;


int32_t Pwm_By_Speed_normalR(float vars) {

		/*       FUNCION QUE DESCRIBE ACELERACION
		 *               y = 0,1641x + 10
		 */
	    int16_t speed = (int16_t) vars;
	    int8_t signo = (speed < 0) ? -1 : 1;
	    int16_t magnitud = (speed < 0) ? -speed : speed;

	    	float y = ((0.1641f * magnitud) + 2.0f);
	    	int32_t PerPWM = (int32_t)roundf(y);
	    	PerPWM *= signo;

	    	if (PerPWM > 100) {
	    	    PerPWM = 100;
	    	}
	    	else if (PerPWM < -100) {
	    	    PerPWM = -100;
	    	}
	    	else if (PerPWM >= 0 && PerPWM <= 4) {
	    	    PerPWM = 0;
	    	}

	    return PerPWM;
	}


int32_t Pwm_By_Speed_normalL(float vars) {

		/*       FUNCION QUE DESCRIBE ACELERACION
		 *               y = 0,1641x + 10
		 */
	    int16_t speed = (int16_t) vars;
	    int8_t signo = (speed < 0) ? -1 : 1;
	    int16_t magnitud = (speed < 0) ? -speed : speed;

	    	float y = ((0.1641f * magnitud) + 2.0f);
	    	int32_t PerPWM = (int32_t)roundf(y);
	    	PerPWM *= signo;

	    	if (PerPWM > 100) {
	    	    PerPWM = 100;
	    	}
	    	else if (PerPWM < -100) {
	    	    PerPWM = -100;
	    	}
	    	else if (PerPWM >= 0 && PerPWM <= 4) {
	    	    PerPWM = 0;
	    	}

	    return PerPWM;
	}

/*
int32_t Pwm_By_Speed_normalR(float vars) {

    const float v_dead = 1.0f;
    if (vars > -v_dead && vars < v_dead) return 0;
    int    signo      = (vars < 0.0f) ? -1 : 1;
    float  magnitud   = (vars < 0.0f) ? -vars : vars;  // en vez de fabsf(vars)

    const float a = 0.1641f;
    const float b = 6.0f;
    float y        = a * magnitud + b;

    int32_t PerPWM_R = (int32_t)(y + 0.5f) * signo;

    if (PerPWM_R >  100) PerPWM_R =  100;
    if (PerPWM_R < -100) PerPWM_R = -100;

    return PerPWM_R;
}

int32_t Pwm_By_Speed_normalL(float vars) {
    const float v_dead = 1.0f;
    if (vars > -v_dead && vars < v_dead) return 0;

    int    signo      = (vars < 0.0f) ? -1 : 1;
    float  magnitud   = (vars < 0.0f) ? -vars : vars;  // en vez de fabsf(vars)
    const float a = 0.1641f;
    const float b = 6.0f;
    float y        = a * magnitud + b;

    int32_t PerPWM_L = (int32_t)(y + 0.5f) * signo;      // “round” manual

    if (PerPWM_L >  100) PerPWM_L =  100;
    if (PerPWM_L < -100) PerPWM_L = -100;

    return PerPWM_L;
}*/


void motoresInit(TIM_HandleTypeDef *timmotor, uint32_t canal1, uint32_t canal2){
	timmotorGlobal = timmotor;
	HAL_TIM_PWM_Start(timmotorGlobal, canal1);   // OUT PWMA
	HAL_TIM_PWM_Start(timmotorGlobal, canal2);  // OUT PWMB
	timmotorGlobal->Instance->CCR1 = 0;
	timmotorGlobal->Instance->CCR2 = 0;

	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,0);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5,0);
}

void motores(int32_t m1, int32_t m2){

	//control motor 1
	int8_t pwmM1 = Pwm_By_Speed_normalL(m1); //L

    int8_t pwmM2 = Pwm_By_Speed_normalR(m2); //R

	if(pwmM1 > 0){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,1);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0);
		if(pwmM1 > 100)pwmM1 = 100;
		timmotorGlobal->Instance->CCR1 = pwmM1;
	}else if(pwmM1 < 0){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,1);
		pwmM1 *= -1;
		if(pwmM1 > 100)pwmM1 = 100;     //L
		timmotorGlobal->Instance->CCR1 = pwmM1;
	}else{                                       /// NORMALMENTE SOLO EJECUTA EN 0,0 FREE
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6,0);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7,0);
		timmotorGlobal->Instance->CCR1 = 0;  //LEFT
	}

	//control motor 2
	if(pwmM2 > 0){
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,1);  //COMANDO ADELANTE
		HAL_GPIO_WritePin(GPIOB	, GPIO_PIN_10,0);
		if(pwmM2 > 100)pwmM2 = 100;
		timmotorGlobal->Instance->CCR2 = pwmM2;
	}else if(pwmM2 < 0){
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,0);   //COMANDO ATRAS
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10,1);
		pwmM2 *= -1;
		if(pwmM2 > 100)pwmM2 = 100;
		timmotorGlobal->Instance->CCR2 = pwmM2;  //R
	}else{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2,0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10,0);
		timmotorGlobal->Instance->CCR2 = 0;  //RIGHT
	}

}
