/*
 * PID_MM.c
 *
 *  Created on: May 11, 2025
 *      Author: YEISON LARA
 */
/*
 * PID_MM.c
 *
 *  Created on: May 11, 2025
 *      Author: YEISON LARA
 */

#include "PID_MM2.h"
#include "mms_odometria.h"

VARIABLES_PID pidLIN;
VARIABLES_PID pidANG;

void PID_Init_Linear(float kp, float kd) {
    pidLIN.Kp      = kp;
    pidLIN.Kd      = kd;
    pidLIN.ERR_ANT = 0.0f;
}

void PID_Init_Angular(float kp, float kd) {
    pidANG.Kp      = kp;
    pidANG.Kd      = kd;
    pidANG.ERR_ANT = 0.0f;
}


float PID_Update_Linear(float error, float dt) {
    float P = pidLIN.Kp * error;
    float D = pidLIN.Kd * ((error - pidLIN.ERR_ANT) / dt);
    pidLIN.ERR_ANT = error;

    float out = P + D;
    return out;
}

float PID_Update_Angular(float error, float dt) {
    float P = pidANG.Kp * error;
    float D = pidANG.Kd * ((error - pidANG.ERR_ANT) / dt);
    pidANG.ERR_ANT = error;

    float out = P + D;

    if (out >  500.0f) out =  500.0f;
    if (out < -500.0f) out = -500.0f;

    return out;
}

