/*
 * COMUNICATION_MM.c
 *
 *  Created on: May 10, 2025
 *      Author: YEISON LARA
 */

/*
#include "COMUNICATION_MM.h"

static UART_HandleTypeDef *uart_handle = NULL;
static uint8_t  *rx_buffer  = NULL;

PAQUETE pk1;

uint8_t datosx[50]; // PARA DARLE MEMORIA POSIBLE PARA LA ESTRUCTURA (DATOS.STRUCT)

uint8_t dataTX[40]; //BUFFER PARA ENVIO DE DATOS
int8_t numDatos=0;


void COMM_MM_Init(UART_HandleTypeDef *huart, uint8_t *rx_buf) {

    uart_handle = huart;
    rx_buffer   = rx_buf;
    // Arranca la recepción por interrupción:
    HAL_UART_Receive_IT(uart_handle, rx_buffer, 1);
}


uint8_t calcularCRC(uint8_t *datos, uint8_t tam) //el valor de tam cuando llega
{
	uint8_t crc = 0;

		for(int i=0; i<tam; i++)
		{
			crc ^= datos[i];
		}

	return crc;
}

int8_t serializarPaquete(const PAQUETE* paquete, uint8_t *buffer){   //serialize

	int idx =0;

	if(!paquete || !buffer)return -1;

	buffer[idx++] = paquete->inicio;
	buffer[idx++]= paquete->tamano;

	if(paquete->datos && (paquete->tamano>3))
	{   	//packet of data ;
		memcpy(&buffer[idx], paquete->datos, (size_t)(paquete->tamano-4));
		idx = idx + paquete->tamano-4;
	}

	uint8_t ss= (uint8_t)idx;
	buffer[idx++] = calcularCRC(buffer,ss);
	buffer[idx++] = paquete->fin;
	return idx;
}

void EnviarPaquete(uint8_t *dat, uint8_t tam){

	pk1.inicio = 0x77; //Start byte
	pk1.tamano = tam + 4;
	pk1.datos = datosx;

    memcpy(&pk1.datos[0], dat, tam + 4 );

	numDatos = serializarPaquete(&pk1, &dataTX);
	pk1.crc = calcularCRC(dataTX, tam+4);
	pk1.fin =0x12;

	//CDC_Transmit_FS(dataTX, numDatos);  ///aQUI

    HAL_UART_Transmit_IT(uart_handle, dataTX, numDatos);


} //way important to transmit

uint8_t fragmentacion(uint32_t dato, uint8_t frag_array[], uint8_t posicion) {

	/* MI FUNCION LLENA HACIA LA DERECHA DESDE LA POSICION QUE UNO DIGA LLENA 1 BYTE
	 *  POSICION DEPENDE DE MI Y ARREGLO Y DATO SON LOS QUE UNO QUIERE COMUNICAR PARA LA FUNCION ENVIARPAQUETE();
	 *  ADEMAS ORGANIZA AUTOMATICAMENTE.
	 */

/*
	uint8_t i = 0;
    while (dato > 255) {
        frag_array[posicion + i] = 0xFF;
        dato -= 255;
        i++;
    }

    frag_array[posicion + i] = dato & 0xFF;
    int8_t NFRAG = i+1;
    return NFRAG; //  REVISAR NUMERO DE FRAGMENTACIONES EN VIVO...
}
*/
