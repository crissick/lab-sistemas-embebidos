/*
 * PID_MM.c
 *
 *  Created on: May 11, 2025
 *      Author: YEISON LARA
 */

/*
#include "PID_MM.h"


#include "mms_odometria.h"

VARIABLES_PID vars_pid;
float proporcional = 0;
float diferencial = 0;
float integral = 0;
float outputPID = 0;
bool control_INTEGRAL = 0;

void PID_INIT(float kp, float kd, float ki)
{
	vars_pid.Kp = kp;
	vars_pid.Kd = kd;
	vars_pid.Ki = ki;
}



float PID_UPDATE(float error, float dt)
{

	proporcional = 0;
	diferencial = 0;
	proporcional = error * vars_pid.Kp;
	diferencial = vars_pid.Kd * ((error - vars_pid.ERR_ANT)/dt);
	vars_pid.ERR_ANT = error;

	outputPID = proporcional+diferencial;   //+integral;
	if (outputPID>500) outputPID = 500;
	return outputPID;
}

*/
