/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "motorDriver.h"
#include "retardos.h"
#include <stdbool.h>
#include "usbd_cdc_if.h"
#include "stm32f4xx_hal.h"
#include "math.h"
#include "mms_odometria.h"
#include "COMUNICATION_MM.h"
#include "MOVEMENT_MM.h"
#include "TRAPECIO.h"
#include "PID_MM.h"
#include "PID_MM2.h"
#include "adc_custom.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define PI               3.14159265f
#define WHEEL_RADIUS_MM  15.0f
#define PULSES_PER_REV   1135
#define WHEEL_BASE_MM    80.0f
#define TELEPLOT_IP    "192.168.85.201"
#define TELEPLOT_PORT  47269

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim9;
TIM_HandleTypeDef htim10;
TIM_HandleTypeDef htim11;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
/*lib profe*/

int32_t resultados[4] = {0};
int32_t apagados[4] = {0};
int32_t encendidos[4] = {0};
int32_t diferencia[4] = {0};

int8_t numDatos=0;



//////////////////////////////////////////////////////////////////////////////////

/*
const long SENSOR_MIN[4] = {10, 10, 10, 10};   // lecturas muy cerca
const long SENSOR_MAX[4] = {4090, 5000, 4090, 4090}; // lecturas muy lejos

const long MAP_OUT_MIN[4] = { 10.0, 20.0, 15.0, 5.0 };
const long MAP_OUT_MAX[4] = { 4100.0, 2000.0, 4050.0, 4200.0 };
*/

bool DetectoDerecha = 0;
bool DetectoIzquierda = 0;

const long SENSOR_MIN[4] = {  10, 1000,   3,   7   };
const long SENSOR_MAX[4] = { 272,  5000, 2169, 2542 };

const long MAP_OUT_MIN[4] = { 5,   10,   30,   49   };
const long MAP_OUT_MAX[4] = { 3587, 4000, 3690, 3388 };

long raw = 0;
long salida[4] = {0};
float DISTANCIAS[4] = {0};

uint16_t d0 ;
uint16_t d1 ;
uint16_t d2 ;
uint16_t d3 ;

float mm_DESIRED = 0.0f;

////////////////////////////////////////////////////////////////////////////////////

GPIO_TypeDef* puertos_led[4] = {GPIOB, GPIOB, GPIOA, GPIOB};
uint16_t pines_led[4] = {GPIO_PIN_14, GPIO_PIN_15, GPIO_PIN_8, GPIO_PIN_9};

float speed_pr;//LAB 11
float speed_pr_angulo;

float ERROR_TEMP_L = 0.0f;
float ERROR_TEMP_R = 0.0f;

float PID_VALUE_L=0;  //revisar puede ser UINT
float PID_VALUE_R=0;  //revisar puede ser UINT

float PID_VALUE_L_ANG=0;  //revisar puede ser UINT
float PID_VALUE_R_ANG=0;  //revisar puede ser UINT

Pose ps;

char texto[100]; //SPRINTF/NO BORRAR

 //POSIBLE PROBLEMA FUTURO NO 8 BYTES
uint16_t Freq;
int16_t SPEEDE;
uint8_t datosTX[40];

uint8_t DatosRX[51];  // COMUNICACION CON QT // BUFFER RECEPTOR
volatile uint8_t indexRX = 0; // TAMAÑO DE DATOS RECIBIDOS//QT
uint8_t datosx [40];


uint32_t  MMS;

volatile uint16_t RPM;

volatile int8_t revision;

uint8_t COMUNICACION[20];
uint8_t pos = 0;//IMPORTANTE NO BORRAR PARTE DEL ARREGLO COMUNICACION Y LA FUNCION FRAGMENTAR BYTE

volatile int16_t pulsosR_temp;
volatile int32_t pulsosR_dt;
volatile int32_t pulsosL_dt;

volatile int32_t pulsosR;
volatile int32_t pulsosL;   //TENER EN CUENTA

float velMotores = 0;
int32_t pwmTrapecio = 0;

int32_t dL;  //NO BORRAR
int32_t dR;  //NO BORRAR

int32_t DL;  //NO BORRAR
int32_t DR;  //NO BORRAR



typedef struct{
	uint8_t inicio_EN;
	uint8_t tamano_EN;
	uint8_t *datos_EN;  //RECORDOR NOMBRE
	uint8_t fin_EN;

}ENVIAPAQUETE;

ENVIAPAQUETE np;

typedef struct{
	uint8_t inicio;
	uint8_t tamano;
	uint8_t *datos;  //changeable
	uint8_t crc;
	uint8_t fin;

}PAQUETE;
PAQUETE pk1;

typedef enum {
    TLED=0,
	TWDOG,
    T_PHASE1, T_PHASE2, T_PHASE3, T_PHASE4, T_PHASE5,
    F_PHASE1, F_PHASE2, F_PHASE3, F_PHASE4, F_PHASE5,
    TSPEED,
	TTOTAL,
	TTALK,
	DETCTN,
	STATE_MAC
} TIMERS;

volatile uint32_t tim_pro[TTOTAL];
uint32_t timers[TTOTAL] = {0};


//void ReciboPaquete(const PAQUETE* paquete, uint8_t *pos){}

unsigned char teleplotchar [120]; //MIRARA


uint32_t adc_0; //este tambien
uint32_t adc_1;
uint32_t adc_2;
uint32_t adc_3;
uint32_t adc_4; //revisar o borrar


uint8_t calcularCRC(uint8_t *datos, uint8_t tam) //el valor de tam cuando llega
{
	uint8_t crc = 0;

		for(int i=0; i<tam; i++)
		{
			crc ^= datos[i];
		}

	return crc;
}

void EnviarPaquete(uint8_t *dat, uint8_t tam){

	pk1.inicio = 0x77; //Start byte
	pk1.tamano = tam + 4;
	pk1.datos=datosx;

    memcpy(&pk1.datos[0], dat, tam + 4 );

	numDatos = serializarPaquete(&pk1, &datosTX);
	pk1.crc=calcularCRC(datosTX, tam+4);
	pk1.fin =0x12;


	HAL_UART_Transmit_IT(&huart1, datosTX, numDatos);
	//CDC_Transmit_FS(datosTX, numDatos);  ///////////////////////////////////////////aQUI


} //way important to transmit

	uint8_t velocidad = 200;
    char buffer[200];


    void ENVIAR_Teleplot(float VelMotorL, float VelMotorR, float distir1, float distir2, float distir3, float distir4)
    {
   		//sprintf(texto, "vel:%d\n ML:%f\n  M%d\n", velocidad, ps.velMotorL, ps.velMotorR);
   		//HAL_UART_Transmit(&huart1, (uint8_t*)texto, strlen(texto),1000);

        sprintf(buffer,"VMotorL:%f\n VMotorR:%f\n DistIR1:%f\n DistIR2:%f\n DistIR3:%f\n DistIR4:%f\n",VelMotorL, VelMotorR, distir1, distir2, distir3, distir4);
        HAL_UART_Transmit(&huart1, (uint8_t*)buffer, strlen(buffer), 1000);//ASI PARA PODER VISUALIZAR
    }


uint8_t fragmentacion(uint32_t dato, uint8_t frag_array[], uint8_t posicion) {

	/* MI FUNCION LLENA HACIA LA DERECHA DESDE LA POSICION QUE UNO DIGA LLENA 1 BYTE
	 *  POSICION DEPENDE DE MI Y ARREGLO Y DATO SON LOS QUE UNO QUIERE COMUNICAR PARA LA FUNCION ENVIARPAQUETE();
	 *  ADEMAS ORGANIZA AUTOMATICAMENTE.
	 */
	uint8_t i = 0;
    while (dato > 255) {
        frag_array[posicion + i] = 0xFF;
        dato -= 255;
        i++;
    }

    frag_array[posicion + i] = dato & 0xFF;
    int8_t NFRAG = i+1;
    return NFRAG; //  REVISAR NUMERO DE FRAGMENTACIONES EN VIVO...
}


int32_t corregir_overflow(int16_t actual, int16_t anterior) {
    int32_t delta = (int32_t)actual - (int32_t)anterior;

    if (delta > 32767)
        delta -= 65536;
    else if (delta < -32768)
        delta += 65536;

    return delta;
}


static uint16_t lastCountL16 = 0;
static uint16_t lastCountR16 = 0;
uint16_t pulseL;
uint16_t pulseR;

void leer_pulsos(void)
{

    pulseL = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
    pulseR = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);

    int16_t aL = (int16_t)pulseL;
    int16_t pL = (int16_t)lastCountL16;
    int16_t aR = (int16_t)pulseR;
    int16_t pR = (int16_t)lastCountR16;

    dL = corregir_overflow(aL, pL);
    dR = corregir_overflow(aR, pR);

    lastCountL16 = pulseL;
    lastCountR16 = pulseR;

    pulsosL_dt += dL;
    pulsosR_dt += dR;
}

float calc_vel_pid(float vel_actual, float vel_referencia, float dt) {
    float error = vel_referencia - vel_actual;

    //return vel_referencia + PID_UPDATE(error, dt);  //desbloquear PID_MM1 SI ALGO
    return vel_referencia + PID_Update_Linear(error, dt);

}

float calc_vel_pid_Angular(float vel_actual, float vel_referencia, float dt) {
    float error = vel_referencia - vel_actual;
    //return vel_referencia + PID_UPDATE(error, dt);
    return vel_referencia + PID_Update_Linear(error, dt);

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Mapea x ∈ [in_min, in_max] a y ∈ [out_min, out_max] usando escala logarítmica.
 * Todos los parámetros deben ser > 0, y x se saturará dentro de [in_min, in_max].
	 */

	long mapLog(long x, long in_min, long in_max, long out_min, long out_max) {
		// Aseguramos valores válidos y > 0
		if (in_min < 1)in_min  = 1;
		if (in_max <= in_min) in_max = in_min + 1;
		if (x < in_min) x = in_min;
		if (x > in_max) x = in_max;

		double logMin = log((double)in_min);
		double logMax = log((double)in_max);
		double logX   = log((double)x);

		double frac = (logX - logMin) / (logMax - logMin);
		return (long)(out_min + frac * (out_max - out_min));
	}


void sensing_point(){
	for(int i = 0; i < 4; i++)
	{
		switch(i)
		{
			case 0:
				apagados[i] = ADC_SelectCH(&hadc1, ADC_CHANNEL_0);
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 1);
				delay_us_tim(120);
				encendidos[i] = ADC_SelectCH(&hadc1, ADC_CHANNEL_0);
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 0);
					break;
			case 1:
				apagados[i] = (ADC_SelectCH(&hadc1, ADC_CHANNEL_1));
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 1);
				delay_us_tim(50);
				encendidos[i] = (ADC_SelectCH(&hadc1, ADC_CHANNEL_1)*2);
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 0);
					break;
			case 2:
				apagados[i] = ADC_SelectCH(&hadc1, ADC_CHANNEL_2);
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 1);
				delay_us_tim(105);
				encendidos[i] = ADC_SelectCH(&hadc1, ADC_CHANNEL_2);
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 0);
					break;
			case 3:
				apagados[i] = ADC_SelectCH(&hadc1, ADC_CHANNEL_3);
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 1);
				delay_us_tim(120);
				encendidos[i] = ADC_SelectCH(&hadc1, ADC_CHANNEL_3);
				HAL_GPIO_WritePin(puertos_led[i], pines_led[i], 0);
					break;
		}
	}
}




float DIST1_FX(float raw) {
    if      (raw <  21.0f) raw =  21.0f;
    else if (raw > 200.0f) raw = 200.0f;

    const float in_min  =  21.0f;
    const float in_max  = 200.0f;
    const float out_min =  40.0f;
    const float out_max =  90.0f;

    double logMin = log((double)in_min);
    double logMax = log((double)in_max);
    double logX   = log((double)raw);
    double frac   = (logX - logMin) / (logMax - logMin);
    float out     = (float)(out_min + frac * (out_max - out_min));

    static float y1 = 0.0f;
    y1 += 0.2f * (out - y1);
    return y1;
}


float DIST2_FX(float raw) {
    if      (raw <   8.0f) raw =   8.0f;
    else if (raw > 200.0f) raw = 200.0f;

    float r2 = raw*raw, r3 = r2*raw, r4 = r3*raw;

    const float a2 = -0.000001132f;
    const float b2 =  0.000397209f;
    const float c2 = -0.04335164f;
    const float d2 =  2.837492f;
    const float e2 =  1.50791f;

    float out = a2*r4 + b2*r3 + c2*r2 + d2*raw + e2;

    static float y2 = 0.0f;
    y2 += 0.2f * (out - y2);
    return y2;
}


float DIST3_FX(float raw) {
    if      (raw <  26.0f) raw =  26.0f;
    else if (raw > 166.0f) raw = 166.0f;
    float r2 = raw*raw, r3 = r2*raw, r4 = r3*raw;
    const float a3 = -0.00000221161921f;
    const float b3 =  0.000805596339f;
    const float c3 = -0.100674068f;
    const float d3 =  5.81133641f;
    const float e3 = -96.1875810f;
    float out = a3*r4 + b3*r3 + c3*r2 + d3*raw + e3;
    static float y3 = 0.0f;
    y3 += 0.2f * (out - y3);
    return y3;
}

float DIST4_FX(float raw) {
    if      (raw <   3.0f) raw =   3.0f;
    else if (raw > 200.0f) raw = 200.0f;

    float r2 = raw * raw;
    float r3 = r2  * raw;
    float r4 = r3  * raw;

    const float in_min  =   3.0f;
    const float in_max  = 200.0f;
    const float out_min =  30.0f;  // antes 20 mm, ahora +10 mm
    const float out_max = 130.0f;  // antes 120 mm, ahora +10 mm

    double logMin = log((double)in_min);
    double logMax = log((double)in_max);
    double logX   = log((double)raw);
    double frac   = (logX - logMin) / (logMax - logMin);
    float out     = (float)(out_min + frac * (out_max - out_min));

    static float y4 = 0.0f;
    y4 += 0.2f * (out - y4);

    return y4;
}


void Deteccion()
{
	if(DISTANCIAS[1] < 40)
	{
		DetectoIzquierda = 1;
	}
	if(DISTANCIAS[2] < 55)
	{
		DetectoDerecha = 1;
	}
}

typedef enum{
	STATE_LEER,
	STATE_ESPERA,
	STATE_FRENTE,
	STATE_GIRO_DERECHA,
	STATE_GIRO_IZQUIERDA
}MAC_ST;

MAC_ST current_state = STATE_FRENTE;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM9_Init(void);
static void MX_TIM4_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM11_Init(void);
static void MX_TIM10_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
void F_STATE_LEER(void);
void F_STATE_ESPERA(void);
void F_STATE_FRENTE(void);
void F_STATE_GIRO_DERECHA(void);
void F_STATE_GIRO_IZQUIERDA(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void STATE_MACHINE_RUN(void)
{
	switch (current_state)
	{

	case STATE_ESPERA: //// aqui seria un osDelay(5);
		current_state = STATE_LEER;
		break;

	case STATE_LEER:
		Deteccion();
		if(DetectoDerecha)
		{
			DetectoDerecha = 0;
			current_state = STATE_GIRO_IZQUIERDA;
		}else if(DetectoIzquierda)
		{
			DetectoIzquierda = 0;
			current_state = STATE_GIRO_DERECHA;
		}else {
			current_state = STATE_FRENTE;
		}

		break;

	case STATE_FRENTE:
				//----PROBAR SI VA BIEN----//
		speed_pr = trapecio_perpetuo(ps.avanceLineal, 0.005f, DISTANCIAS[3], 500.0f, 400.0f, 0.0f, 1.0f, 200.0f);
		float VELL_WPID = calc_vel_pid(ps.velMotorL, speed_pr, 0.005);
		float VELR_WPID = calc_vel_pid(ps.velMotorR, speed_pr, 0.005);
		motores(VELL_WPID, VELR_WPID);
		if(speed_pr == 0)
		{
			current_state = STATE_LEER;
		}

	case STATE_GIRO_DERECHA:
		speed_pr_angulo = trapecio_Angular(ps.theta, -2.5f, 0.005, 500.0f, 400.0f, 50.0f);
		motores(speed_pr_angulo*2, speed_pr_angulo/2);
		if(speed_pr_angulo == 0)
		{
			current_state = STATE_LEER;
		}
		break;

	case STATE_GIRO_IZQUIERDA:
		speed_pr_angulo = trapecio_Angular(ps.theta, 2.5f, 0.005, 500.0f, 400.0f, 50.0f);
		motores(speed_pr_angulo, speed_pr_angulo);
		if(speed_pr_angulo == 0)
		{
			current_state = STATE_LEER;
		}
		break;
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
   HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM2_Init();
  MX_USB_DEVICE_Init();
  MX_TIM3_Init();
  MX_TIM9_Init();
  MX_TIM4_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM11_Init();
  MX_TIM10_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */



 // Teleplot_UDP_init("192.168.85.201", 47269);
  motoresInit(&htim4, TIM_CHANNEL_1, TIM_CHANNEL_2); //MOTORES
  //COMM_MM_Init(&huart1, &DatosRX);

  HAL_TIM_Base_Start_IT(&htim11);  //ESTOY TRABAJANDO ISR PARA TIM.  :)
  HAL_TIM_Base_Start(&htim9); //ESTO PUDE CAUSAR DESFASE CREO
  HAL_TIM_Base_Start(&htim1);  // SI SE COMPLICA COLOCAR TIMER5 JAJA 9600/10 = MS
  HAL_TIM_Base_Start(&htim10);
  odo_init_reset(&ps);

  ADC_Init_Custom(&hadc1);


  PID_Init_Linear( 0.05f, 0.01f);

  void PID_Init_Angular(float kp, float kd);

  HAL_UART_Receive_IT(&huart1, &DatosRX, 1);

  delay_us_tim_init();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);  //importante por encoder mode t1, t2.

  HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);

  __HAL_TIM_SET_COUNTER(&htim1,0);


  //HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14,1);
  //HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15,1);
  //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8,1);
  //HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9,1);


////////////////////BLOQQUE PARA INCICIAR///////////////
  while ( HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12) == GPIO_PIN_RESET ){}

  HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_15);
  HAL_Delay(450);
  HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_15);
  HAL_Delay(1500);

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, 1); //LED?

  while (1)
  {
/*-----------------------------------------"VISION"-----------------------------------------*/
	  if (tim_pro[TWDOG] == 0)
	  {
		  leer_pulsos();
		  actualizar_odometria(&ps, dL, dR, 0.005);

		  sensing_point();
		  for(uint8_t i = 0; i < 4; i++)
		  {
			  diferencia[i] = abs(encendidos[i] - apagados[i]);
			  raw = diferencia[i];
			  salida[i] = mapLog(raw, SENSOR_MIN[i], SENSOR_MAX[i], MAP_OUT_MIN[i], MAP_OUT_MAX[i]); //DIF WERBETTER
			  DISTANCIAS[i] = CONV_Y_TRANS(salida[i], (i+1));
		  }
			speed_pr = trapecio_perpetuo(ps.avanceLineal, 0.005f, DISTANCIAS[3], 500.0f, 400.0f, 0.0f, 1.0f, 200.0f);
			float VELL_WPID = calc_vel_pid(ps.velMotorL, speed_pr, 0.005);
			float VELR_WPID = calc_vel_pid(ps.velMotorR, speed_pr, 0.005);
			motores(VELL_WPID, VELR_WPID);
		  //STATE_MACHINE_RUN();
		//  Deteccion();




	  tim_pro[TWDOG] = 5;
	  }


	   d0 = DIST1_FX(DISTANCIAS[0]);
	   d1 = DIST2_FX(DISTANCIAS[1]);
	   d2 = DIST3_FX(DISTANCIAS[2]);
	   d3 = DIST4_FX(DISTANCIAS[3]);

	 // if(tim_pro[DETCTN]==0){
	//  Deteccion();

		//  tim_pro[DETCTN] = 8;
	 // }



	   STATE_MACHINE_RUN();




	    if (tim_pro[TLED] == 0) {
	        tim_pro[TLED] = 60;
	        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
	    }


/*--------------------------------COMUNICACION---------------------------------------------*/




	  	  SPEEDE = VSPEED_QT(DatosRX);

	  	  //revision = fragmentacion(RPM, COMUNICACION, 0);
	  	/*  fragmentacion(MMS, COMUNICACION, 2);
	  	  fragmentacion(Freq, COMUNICACION, 5);
	  	  fragmentacion((uint32_t)DISTANCIAS[0], COMUNICACION, 8);
	  	  fragmentacion((uint32_t)DISTANCIAS[1], COMUNICACION, 9);
	  	  fragmentacion((uint32_t)DISTANCIAS[2], COMUNICACION, 10);
	  	  fragmentacion((uint32_t)DISTANCIAS[3], COMUNICACION, 11);*/



		  if(tim_pro[F_PHASE2]==0){

		   	  	ENVIAR_Teleplot((float)ps.velMotorL, (float)ps.velMotorL, DISTANCIAS[0], DISTANCIAS[1], DISTANCIAS[2], DISTANCIAS[3]);


			  //ps.avanceLineal

		   		//sprintf(texto, "vel:%d\n", velocidad);
		   		//sprintf(texto, "vel:%d\n ML:%f\n  M%d\n", velocidad, ps.velMotorL, ps.velMotorR);
		   		//HAL_UART_Transmit(&huart1, (uint8_t*)texto, strlen(texto),1000);

		   		//*/

			    //EnviarPaquete(COMUNICACION, 20);
		   	  	  tim_pro[F_PHASE2]=50;

		  }





		//	HAL_UART_Transmit_IT(&huart1, (uint8_t*)teleplotchar, strlen(teleplotchar));




		  /* m               -----INFOO---
		   *
    float x;
    float y;
    float theta;
    float velMotorL;
    float velMotorR;
    float velLineal;
    float velAngular;
    float avanceLineal;
    float left_distance_mm;
    float right_distance_mm;
    float left_distance_mm_acum;
    float right_distance_mm_acum;
  //ps.velMotorL

		   */


    	  //process_sequence();

	/*  if(tim_pro[TTALK]==0){
		  EnviarPaquete(COMUNICACION, 20);
		  tim_pro[TTALK]=500;
	  }*/

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 5;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 9600-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 15;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 15;
  if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 26-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 100-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief TIM9 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM9_Init(void)
{

  /* USER CODE BEGIN TIM9_Init 0 */

  /* USER CODE END TIM9_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};

  /* USER CODE BEGIN TIM9_Init 1 */

  /* USER CODE END TIM9_Init 1 */
  htim9.Instance = TIM9;
  htim9.Init.Prescaler = 96-1;
  htim9.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim9.Init.Period = 65535;
  htim9.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim9.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim9, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM9_Init 2 */

  /* USER CODE END TIM9_Init 2 */

}

/**
  * @brief TIM10 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM10_Init(void)
{

  /* USER CODE BEGIN TIM10_Init 0 */

  /* USER CODE END TIM10_Init 0 */

  /* USER CODE BEGIN TIM10_Init 1 */

  /* USER CODE END TIM10_Init 1 */
  htim10.Instance = TIM10;
  htim10.Init.Prescaler = 96-1;
  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim10.Init.Period = 65535;
  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM10_Init 2 */

  /* USER CODE END TIM10_Init 2 */

}

/**
  * @brief TIM11 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM11_Init(void)
{

  /* USER CODE BEGIN TIM11_Init 0 */

  /* USER CODE END TIM11_Init 0 */

  /* USER CODE BEGIN TIM11_Init 1 */

  /* USER CODE END TIM11_Init 1 */
  htim11.Instance = TIM11;
  htim11.Init.Prescaler = 96-1;
  htim11.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim11.Init.Period = 1000-1;
  htim11.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim11.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim11) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM11_Init 2 */

  /* USER CODE END TIM11_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA6 PA7 PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB1 PB2 PB10 PB13
                           PB14 PB15 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB12 */
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{

}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  //  static uint16_t ms_counter = 0; declarado arriba

    if (htim->Instance == TIM11) {

        for (uint16_t i = 0; i < TTOTAL; i++) {
            if (tim_pro[i] != 0) {
                tim_pro[i]--;
            }
        }

    }

}

////////////////////////////////////////////////////////////////////////////////////////////////////
/*
void CDC_ReceiveCallBack(uint8_t* Buf, uint32_t Len){
	memcpy(DatosRX,Buf,Len);
	indexRX = Len;
}*/

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
