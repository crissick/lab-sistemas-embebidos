/*
 * COMUNICATION_MM.h
 *
 *  Created on: May 10, 2025
 *      Author: putom
 */

/*

#ifndef COMUNICATION_MM_H_
#define COMUNICATION_MM_H_


#include "stm32f4xx_hal.h"
#include "main.h"

typedef struct{
	uint8_t inicio;
	uint8_t tamano;
	uint8_t *datos;  //changeable
	uint8_t crc;
	uint8_t fin;

}PAQUETE;


void COMM_MM_Init(UART_HandleTypeDef *huart, uint8_t *rx_buf);
uint8_t calcularCRC(uint8_t *datos, uint8_t tam);
int8_t serializarPaquete(const PAQUETE* paquete, uint8_t *buffer);
void EnviarPaquete(uint8_t *dat, uint8_t tam);
uint8_t fragmentacion(uint32_t dato, uint8_t frag_array[], uint8_t posicion);


#endif /* COMUNICATION_MM_H_ */


