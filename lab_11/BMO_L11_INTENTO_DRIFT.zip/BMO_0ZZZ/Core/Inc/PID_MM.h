/*
 * PID_MM.h
 *
 *  Created on: May 11, 2025
 *      Author: YEISON LARA
 */


/*
#ifndef PID_MM_H_
#define PID_MM_H_

#include "main.h"
#include <stdbool.h>


typedef struct{
    float Kp;
    float Kd;
    float Ki;
    float ERR_ANT;
} VARIABLES_PID;


void PID_INIT(float kp, float kd, float ki);

float PID_UPDATE(float error, float dt);

#endif /* PID_MM_H_ */


